class Screen {
  constructor(x, y, image) {
    this.x = x;
    this.y = y;
    this.image = image;
  }
  display() {}
}
