class Sound {
  constructor(volume, start, stop, time) {
    this.volume = volume;
    this.start = start;
    this.stop = stop;
    this.time = time;
    this.isPlayed = false;
  }
  count() {}
  play() {}
  // start(){} ?
  // stop(){} ?
}
