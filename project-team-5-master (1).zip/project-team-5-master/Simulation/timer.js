class Timer {
  constructor(time) {
    this.time = time;
  }
  count() {}
}
